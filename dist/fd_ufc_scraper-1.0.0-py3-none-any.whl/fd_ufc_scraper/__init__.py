from .fd_ufc_scraper import (
    get_fighter,
    get_event,
    get_upcoming_events
)

__all__ = [
    "get_fighter",
    "get_event",
    "get_upcoming_events"
]
